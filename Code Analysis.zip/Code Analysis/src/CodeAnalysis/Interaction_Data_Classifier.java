package CodeAnalysis;


import CodeAnalysis.DataCheck;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author jeffreyyoung
 */
public class Interaction_Data_Classifier {

    public static void main(String[] args) throws IOException {

        ArrayList<ArrayList<String>> data = new ArrayList<>(); //stores inputs
        input(data, "NewTrain");

        System.out.println("# of Data Points");
        for (int i = 0; i < data.size(); i++) {
            System.out.println(data.get(i).size());
        }

        Sim s = new Sim(data);

        ArrayList<ArrayList<Double>> Vdata = s.getVecData(data, 10.0);

        NNet n = new NNet();

        DataCheck dC = new DataCheck();

        for (int i = 0; i < Vdata.size() - 1; i++) {
            double gain = dC.getEntropy(Vdata.get(Vdata.size() - 1)) - dC.getGain(Vdata.get(Vdata.size() - 1), Vdata.get(i));
            double coor = dC.correlation(Vdata.get(i), Vdata.get(Vdata.size() - 1));
            System.out.println(gain + " :Gain");
            System.out.println(coor + " :Coor");
            if (gain < 0.50 || coor < 0.10) {
                Vdata.remove(i);
                i--;
            }
        }
        System.out.println("V size: " + Vdata.size());
        n.run(Vdata);

        IsQ Q = new IsQ();
        //predict.....
        ArrayList<ArrayList<String>> test = new ArrayList<>(); //stores inputs
        input(test, "FullQ1");

        ArrayList<String> out = new ArrayList<>();
        ArrayList<String> out2 = new ArrayList<>();
        for (int x = 0; x < test.get(0).size(); x++) {

            if (Q.Q(test.get(0).get(x))) {
                ArrayList<ArrayList<String>> test2 = new ArrayList<>();
                test2.add(new ArrayList<>());
                test2.get(0).add(test.get(0).get(x));
                ArrayList<ArrayList<Double>> Vtest = s.getVecData(test2, 100.0);
                System.out.println(Vtest.size());
                ArrayList<Double> X = new ArrayList<>();
                for (int i = 0; i < Vtest.size(); i++) {
                    X.add(Vtest.get(i).get(0));
                }
                double cl = Math.round(n.predict(X));
                if (cl == 1.0 || cl == 0.0) {
                    out.add(test.get(0).get(x));
                    out2.add(Double.toString(cl));
                    System.out.println(test.get(0).get(x) + " Cl: " + cl);
                }
                test2.get(0).clear();
            }
        }
        //writeData(out, "LabeledQuestions1");
        //writeData(out2, "Classes1");

    }

    public static void writeData(ArrayList<String> rows, String n) throws IOException {

        FileWriter csvWriter = null;
        try {
            csvWriter = new FileWriter("//Users/jeffreyyoung/Desktop/Alexa Code/" + n + ".csv");
        } catch (IOException ex) {
            Logger.getLogger(Get_Interaction_Data.class.getName()).log(Level.SEVERE, null, ex);
        }

        for (int j = 0; j < rows.size(); j++) {
            csvWriter.append(rows.get(j));
            csvWriter.append(",");
            csvWriter.append("\n");
        }

        csvWriter.flush();
        csvWriter.close();

        System.out.println("OutPut: " + n);
    }

    public static void input(ArrayList<ArrayList<String>> data, String name) throws IOException {

        ArrayList<ArrayList<XSSFCell>> cells = new ArrayList<>();

        File myFile = new File("//Users/jeffreyyoung/Desktop/Alexa Code/" + name + ".xlsx");
        FileInputStream fis = null;

        fis = new FileInputStream(myFile);

        XSSFWorkbook wb = null;

        wb = new XSSFWorkbook(fis);

        XSSFSheet sheet = wb.getSheetAt(0);

        XSSFRow row;
        XSSFCell cell = null;

        int rows; // No of rows
        rows = sheet.getPhysicalNumberOfRows();

        System.out.println("rows = " + rows);
        int cols = 0; // No of columns
        int tmp = 0;

        // This trick ensures that we get the data properly even if it doesn't start from first few rows
        for (int i = 0; i < 10 || i < rows; i++) {
            row = sheet.getRow(i);
            if (row != null) {
                tmp = sheet.getRow(i).getPhysicalNumberOfCells();
                if (tmp > cols) {
                    cols = tmp;
                }
            }
        }
        for (int n = 0; n < cols; n++) {
            cells.add(new ArrayList<>()); //fills arraylists for number of columns
            data.add(new ArrayList<>());
        }

        System.out.println("rows 2: " + rows);
        System.out.println("cols: " + cols);
        for (int r = 0; r < rows * 2; r++) { //*2 to fix halfing problem
            row = sheet.getRow(r);
            if (row != null) {
                for (int c = 0; c < cols; c++) {
                    cell = row.getCell((short) c);
                    if (cell != null) {
                        cells.get(c % cols).add(cell);
                    }
                }
            }
        }

        for (int i = 0; i < cells.size(); i++) {
            System.out.println("Cell " + i + " contain n = : " + cells.get(i).size());
            for (int j = 0; j < cells.get(i).size(); j++) { //adjust to isolate years
                cells.get(i).get(j).setCellType(CellType.STRING); //convert cell to numeric
                data.get(i).add(cells.get(i).get(j).getStringCellValue()); //convert cell to double and add to arraylist
            }
        }
        //-------------------input data end-------------------------------------
    }

}
