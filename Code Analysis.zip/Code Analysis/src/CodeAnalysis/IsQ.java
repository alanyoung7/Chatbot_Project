package CodeAnalysis;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author jeffreyyoung
 */
public class IsQ {

    ArrayList<ArrayList<String>> data = new ArrayList<>();

    IsQ() throws IOException {
        disableWarning();
        String Name = "//Users/jeffreyyoung/Desktop/Clemson/chatBot/pre.xlsx";
        input(data, Name);

        //isolates words
        for (int i = 0; i < data.get(1).size(); i++) {
            String t = data.get(1).get(i), st = "";
            for (int j = 0; j < t.length(); j++) {

                if (t.charAt(j) != ' ') {
                    st += t.charAt(j);
                }
            }
            data.get(1).remove(i);
            data.get(1).add(i, st);
        }
        //makePre(data);

    }

    boolean Q(String Qdata) {

        String s = findQ(data, Qdata);
        return s.length() > 0;

    }

    String findQ(ArrayList<ArrayList<String>> pre, String s) {

        String s1 = s.toLowerCase().replaceAll("\\p{Punct}", "");

        ArrayList<String> q = new ArrayList<>();
        String t = "";
        for (int i = 0; i < s1.length(); i++) {
            if (s1.charAt(i) != ' ') {
                t += s1.charAt(i);
            } else {
                q.add(t);
                t = "";
            }
        }
        q.add(t);

        String question = "";
        outer:
        for (int i = 0; i < pre.get(0).size(); i++) {

            for (int j = 0; j < q.size() - 1; j++) {
                if (q.get(j).equals(pre.get(0).get(i)) && q.get(j + 1).equals(pre.get(1).get(i))) {

                    for (int k = j; k < q.size(); k++) {
                        question += (q.get(k) + " ");
                    }
                    break outer;
                }
            }
        }

        return question;

    }

    void makePre(ArrayList<ArrayList<String>> pre) {
        ArrayList<ArrayList<String>> temp = new ArrayList<>();

        for (int i = 0; i < pre.size(); i++) {
            temp.add(new ArrayList<>());
            for (int j = 0; j < pre.get(0).size(); j++) {
                temp.get(i).add(pre.get(i).get(j));
            }
        }

        pre.clear();
        pre.add(new ArrayList<>());
        pre.add(new ArrayList<>());
        for (int i = 0; i < temp.get(0).size(); i++) {
            String st = temp.get(0).get(i);
            for (int j = 0; j < temp.get(0).size(); j++) {
                pre.get(0).add(st);
                pre.get(1).add(temp.get(1).get(j));
            }
        }

    }

    void disableWarning() {
        System.err.close();
        System.setErr(System.out);
    }

    void input(ArrayList<ArrayList<String>> data, String name) throws FileNotFoundException, IOException {

        //----------------------input data start--------------------------------
        ArrayList<ArrayList<XSSFCell>> cells = new ArrayList<>();

        File myFile = new File(name);
        FileInputStream fis = null;

        fis = new FileInputStream(myFile);

        XSSFWorkbook wb = null;

        wb = new XSSFWorkbook(fis);

        XSSFSheet sheet = wb.getSheetAt(0);

        XSSFRow row;
        XSSFCell cell = null;

        int rows; // No of rows
        rows = sheet.getPhysicalNumberOfRows();

        System.out.println("rows = " + rows);
        int cols = 0; // No of columns
        int tmp = 0;

        // This trick ensures that we get the data properly even if it doesn't start from first few rows
        for (int i = 0; i < 10 || i < rows; i++) {
            row = sheet.getRow(i);
            if (row != null) {
                tmp = sheet.getRow(i).getPhysicalNumberOfCells();
                if (tmp > cols) {
                    cols = tmp;
                }
            }
        }
        for (int n = 0; n < cols; n++) {
            cells.add(new ArrayList<>()); //fills arraylists for number of columns
            data.add(new ArrayList<>());
        }

        System.out.println("rows 2: " + rows);
        System.out.println("cols: " + cols);
        for (int r = 0; r < rows * 2; r++) { //*2 to fix halfing problem
            row = sheet.getRow(r);
            if (row != null) {
                for (int c = 0; c < cols; c++) {
                    cell = row.getCell((short) c);
                    if (cell != null) {
                        cells.get(c % cols).add(cell);
                    } else {
                        cell = row.createCell((short) c);
                        cell.setCellValue("000");
                        cells.get(c % cols).add(cell);
                    }
                }
            }
        }

        for (int i = 0; i < cells.size(); i++) {
            System.out.println("Cell " + i + " contain n = : " + cells.get(i).size());
            for (int j = 1; j < cells.get(i).size(); j++) { //adjust to isolate years
                cells.get(i).get(j).setCellType(CellType.STRING); //convert cell to numeric
                data.get(i).add(cells.get(i).get(j).toString().toLowerCase().replaceAll("\\p{Punct}", "")); //convert cell to double and add to arraylist
            }
        }
        //-------------------input data end-------------------------------------

    }

}
