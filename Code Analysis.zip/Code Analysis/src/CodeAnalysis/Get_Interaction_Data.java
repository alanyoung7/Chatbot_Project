package CodeAnalysis;


import java.io.File;  // Import the File class
import java.io.FileInputStream;
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner; // Import the Scanner class to read text files
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

//retrieves interaction data from source code
public class Get_Interaction_Data {

    static String name;

    static Set<String> hs = new HashSet();
    static ArrayList<ArrayList<String>> l = new ArrayList<>();

    public static void main(String[] args) throws IOException {

        ArrayList<String> names = new ArrayList<>();
        read(names);

        disableWarning();
        String Name = "//Users/jeffreyyoung/Desktop/Clemson/chatBot/pre.xlsx";
        ArrayList<ArrayList<String>> data = new ArrayList<>();
        input(data, Name);

        for (int i = 0; i < data.get(1).size(); i++) {
            String t = data.get(1).get(i), st = "";
            for (int j = 0; j < t.length(); j++) {
                if (t.charAt(j) != ' ') {
                    st += t.charAt(j);
                }
            }
            data.get(1).remove(i);
            data.get(1).add(i, st);
        }
        makePre(data);

        l.add(new ArrayList<>());
        l.add(new ArrayList<>());
        for (int i = 0; i < names.size(); i++) {
            name = names.get(i);

            ArrayList<String> l2 = new ArrayList<>();
            try {
                File myObj = new File("//Users/jeffreyyoung/Desktop/Alexa Code/Py2/" + name);
                try (Scanner myReader = new Scanner(myObj)) {
                    while (myReader.hasNextLine()) {

                        String data1 = myReader.nextLine();

                        getQ(data1.trim().replaceAll(" +", " "), l2);

                        if (l2.size() > 0) {
                            l.get(1).add(name);
                            //System.out.println("Q1: " + l.get(l.size() - 1));
                            findQ(data, l2.get(l2.size() - 1));
                        }

                    }
                }
            } catch (FileNotFoundException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
            //writeData(l);
        }

        writeData(l.get(0), "FullQ3");
        writeData(l.get(1), "NamesQ3");

    }

    public static void read(ArrayList<String> l) {

        try {
            File myObj = new File("//Users/jeffreyyoung/Desktop/Alexa Code/namesP2.csv");
            try (Scanner myReader = new Scanner(myObj)) {
                while (myReader.hasNextLine()) {
                    String data = myReader.nextLine();
                    l.add(data);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public static void getQ(String s, ArrayList<String> l) {

        for (int i = 0; i < s.length(); i++) {
            String q = "";
            if (s.charAt(i) == '"') {

                for (int j = i + 1; j < s.length(); j++) {

                    if (s.charAt(j) != '"') {
                        q += s.charAt(j);
                    } else {
                        l.add(q);
                        //System.out.println(q);
                        i = j;
                        break;
                    }
                }
            }
        }
    }

    public static void writeData(ArrayList<String> rows, String n) throws IOException {

        FileWriter csvWriter = null;
        try {
            csvWriter = new FileWriter("//Users/jeffreyyoung/Desktop/Alexa Code/" + n + ".csv");
        } catch (IOException ex) {
            Logger.getLogger(Get_Interaction_Data.class.getName()).log(Level.SEVERE, null, ex);
        }

        for (int i = 0; i < rows.size(); i++) {

            csvWriter.append(rows.get(i));
            csvWriter.append(",");
            csvWriter.append("\n");
        }

        csvWriter.flush();
        csvWriter.close();

        System.out.println("OutPut: " + name);
    }

    public static void findQ(ArrayList<ArrayList<String>> pre, String s) {

        String s1 = s.toLowerCase().replaceAll("\\p{Punct}", "");
        System.out.println("...");

        ArrayList<String> q = new ArrayList<>();
        String t = "";
        for (int i = 0; i < s1.length(); i++) {
            if (s1.charAt(i) != ' ') {
                t += s1.charAt(i);
            } else {
                q.add(t);
                t = "";
            }
        }
        q.add(t);

        String question = ":";
        outer:
        for (int i = 0; i < pre.get(0).size(); i++) {

            for (int j = 0; j < q.size() - 1; j++) {
                if (q.get(j).equals(pre.get(0).get(i)) && q.get(j + 1).equals(pre.get(1).get(i))) {

                    for (int k = j; k < q.size(); k++) {
                        question += (q.get(k) + " ");
                    }
                    break outer;
                }
            }
        }
        if (question.length() > 2) {
            l.get(0).add(question);
        }

    }

    public static void makePre(ArrayList<ArrayList<String>> pre) {
        ArrayList<ArrayList<String>> temp = new ArrayList<>();

        for (int i = 0; i < pre.size(); i++) {
            temp.add(new ArrayList<>());
            for (int j = 0; j < pre.get(0).size(); j++) {
                temp.get(i).add(pre.get(i).get(j));
            }
        }

        pre.clear();
        pre.add(new ArrayList<>());
        pre.add(new ArrayList<>());
        for (int i = 0; i < temp.get(0).size(); i++) {
            String st = temp.get(0).get(i);
            for (int j = 0; j < temp.get(0).size(); j++) {
                pre.get(0).add(st);
                pre.get(1).add(temp.get(1).get(j));
            }
        }

    }

    public static void disableWarning() {
        System.err.close();
        System.setErr(System.out);
    }

    public static void input(ArrayList<ArrayList<String>> data, String name) throws FileNotFoundException, IOException {

        //----------------------input data start--------------------------------
        ArrayList<ArrayList<XSSFCell>> cells = new ArrayList<>();

        File myFile = new File(name);
        FileInputStream fis = null;

        fis = new FileInputStream(myFile);

        XSSFWorkbook wb = null;

        wb = new XSSFWorkbook(fis);

        XSSFSheet sheet = wb.getSheetAt(0);

        XSSFRow row;
        XSSFCell cell = null;

        int rows; // No of rows
        rows = sheet.getPhysicalNumberOfRows();

        System.out.println("rows = " + rows);
        int cols = 0; // No of columns
        int tmp = 0;

        // This trick ensures that we get the data properly even if it doesn't start from first few rows
        for (int i = 0; i < 10 || i < rows; i++) {
            row = sheet.getRow(i);
            if (row != null) {
                tmp = sheet.getRow(i).getPhysicalNumberOfCells();
                if (tmp > cols) {
                    cols = tmp;
                }
            }
        }
        for (int n = 0; n < cols; n++) {
            cells.add(new ArrayList<>()); //fills arraylists for number of columns
            data.add(new ArrayList<>());
        }

        System.out.println("rows 2: " + rows);
        System.out.println("cols: " + cols);
        for (int r = 0; r < rows * 2; r++) { //*2 to fix halfing problem
            row = sheet.getRow(r);
            if (row != null) {
                for (int c = 0; c < cols; c++) {
                    cell = row.getCell((short) c);
                    if (cell != null) {
                        cells.get(c % cols).add(cell);
                    } else {
                        cell = row.createCell((short) c);
                        cell.setCellValue("000");
                        cells.get(c % cols).add(cell);
                    }
                }
            }
        }

        for (int i = 0; i < cells.size(); i++) {
            System.out.println("Cell " + i + " contain n = : " + cells.get(i).size());
            for (int j = 1; j < cells.get(i).size(); j++) { //adjust to isolate years
                cells.get(i).get(j).setCellType(CellType.STRING); //convert cell to numeric
                data.get(i).add(cells.get(i).get(j).toString().toLowerCase().replaceAll("\\p{Punct}", "")); //convert cell to double and add to arraylist
            }
        }
        //-------------------input data end-------------------------------------

    }

}
