/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CodeAnalysis;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author jeffreyyoung
 */
public class GetLabelStats {

    public static void main(String[] args) {

        String name = "weather.txt";
        ArrayList<String> cl = new ArrayList<>();
        try {
            File myObj = new File("//Users/jeffreyyoung/Desktop/Clemson/Alexa_Feedback_Analysis/Final_Result/Classifier/Result_Overall/" + name);
            try (Scanner myReader = new Scanner(myObj)) {
                while (myReader.hasNextLine()) {

                    String data1 = myReader.nextLine(), t = "";

                    for (int i = 0; i < data1.length(); i++) {
                        if (data1.charAt(i) == ']') {
                            for (int j = i + 2; j < data1.length(); j++) {
                                t += data1.charAt(j);
                            }
                        }
                    }

                    cl.add(t.trim().replaceAll(" +", " "));
                    System.out.println(t);

                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        System.out.println(cl.size());
        for (int i = 0; i < cl.size(); i++) {
            if (cl.get(i).isEmpty()) {
                cl.remove(i);
                i--;
            }
        }
        System.out.println(cl.toString());

        Set hs = new HashSet(cl);
        ArrayList<String> a = new ArrayList<>(hs);

        for (int i = 0; i < a.size(); i++) {
            String temp = a.get(i);
            double c = 0.0;
            for (int j = 0; j < cl.size(); j++) {
                if (cl.get(j).equals(temp)) {
                    c++;
                }
            }
            System.out.println(temp + " : " + c);

        }
        System.out.println("Size: " + cl.size());
    }

}
