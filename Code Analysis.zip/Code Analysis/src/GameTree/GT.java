/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GameTree;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author jeffreyyoung GAMETREE
 */
public class GT {

    public static void main(String[] args) throws IOException {

        ArrayList<ArrayList<String>> data = new ArrayList<>(); //stores inputs
        input(data, "TrainGT");

        System.out.println("# of Data Points");
        for (int i = 0; i < data.size(); i++) {
            System.out.println(data.get(i).size());
        }

        ArrayList<String> q = new ArrayList<>(data.get(0));
        ArrayList<String> cl = new ArrayList<>(data.get(1));
        ArrayList<Double> order = new ArrayList<>();
        for (int i = 0; i < data.get(2).size(); i++) {
            order.add(Double.valueOf(data.get(2).get(i)));
        }
        ArrayList<String> ans = new ArrayList<>(data.get(3));

        double layers = Collections.max(order);
        System.out.println("Total Layers = " + layers);

        Set<String> hs = new HashSet<>(ans);
        ArrayList<String> a = new ArrayList<>(hs);

        ArrayList<ArrayList<Double>> L = new ArrayList<>();
        Double c = 1.0;
        for (int i = 0; i < layers; i++) {
            L.add(new ArrayList<>());
            prob(a, ans, order, c++, L.get(i));
        }

        printD(L);

        ArrayList<ArrayList<Double>> gTree = new ArrayList<>();
        ArrayList<ArrayList<String>> gTreeAns = new ArrayList<>();
        for (int i = 0; i < layers; i++) {

            gTree.add(new ArrayList<>());
            gTreeAns.add(new ArrayList<>());
        }

        for (int i = 0; i < L.size(); i++) {
            if (i == 0) {
                for (int j = 0; j < L.get(0).size(); j++) {
                    gTree.get(i).add(L.get(0).get(j));
                    gTreeAns.get(i).add(a.get(i));
                }
            }

            if (i > 0) {
                for (int n = 0; n < gTree.get(i - 1).size(); n++) {
                    double temp = gTree.get(i - 1).get(n);
                    for (int j = 0; j < L.get(i).size(); j++) {
                        gTree.get(i).add(temp * L.get(i).get(j));
                    }
                }
            }
        }

        System.out.println(gTree.get(4).size());
        for (int i = 0; i < gTree.size(); i++) {
            for (int j = 0; j < gTree.get(i).size(); j++) {
                System.out.print(gTree.get(i).get(j) + " ");
            }
            System.out.println();
        }

        System.out.println("--------------------------------");

    }

    public static void prob(ArrayList<String> a, ArrayList<String> ans,
            ArrayList<Double> order, Double cl, ArrayList<Double> p) {

        for (int i = 0; i < a.size(); i++) {
            String s = a.get(i);
            double count = 0.0;
            for (int j = 0; j < ans.size(); j++) {

                if (ans.get(j).equals(s) && order.get(j).equals(cl)) {
                    count++;
                }
            }

            System.out.println(s + " : " + count);
            if (count > 0) {
                p.add(count);
            }
        }

    }

    public static Double prob1(ArrayList<String> a, String key) {

        double count = 0.0;
        for (int i = 0; i < a.size(); i++) {
            if (a.get(i).equals(key)) {
                count++;
            }
        }

        return count / a.size();
    }

    public static void input(ArrayList<ArrayList<String>> data, String name) throws IOException {

        ArrayList<ArrayList<XSSFCell>> cells = new ArrayList<>();

        File myFile = new File("//Users/jeffreyyoung/Desktop/Alexa Code/" + name + ".xlsx");
        FileInputStream fis = null;

        fis = new FileInputStream(myFile);

        XSSFWorkbook wb = null;

        wb = new XSSFWorkbook(fis);

        XSSFSheet sheet = wb.getSheetAt(0);

        XSSFRow row;
        XSSFCell cell = null;

        int rows; // No of rows
        rows = sheet.getPhysicalNumberOfRows();

        System.out.println("rows = " + rows);
        int cols = 0; // No of columns
        int tmp = 0;

        // This trick ensures that we get the data properly even if it doesn't start from first few rows
        for (int i = 0; i < 10 || i < rows; i++) {
            row = sheet.getRow(i);
            if (row != null) {
                tmp = sheet.getRow(i).getPhysicalNumberOfCells();
                if (tmp > cols) {
                    cols = tmp;
                }
            }
        }
        for (int n = 0; n < cols; n++) {
            cells.add(new ArrayList<>()); //fills arraylists for number of columns
            data.add(new ArrayList<>());
        }

        System.out.println("rows 2: " + rows);
        System.out.println("cols: " + cols);
        for (int r = 0; r < rows * 2; r++) { //*2 to fix halfing problem
            row = sheet.getRow(r);
            if (row != null) {
                for (int c = 0; c < cols; c++) {
                    cell = row.getCell((short) c);
                    if (cell != null) {
                        cells.get(c % cols).add(cell);
                    }
                }
            }
        }

        for (int i = 0; i < cells.size(); i++) {
            System.out.println("Cell " + i + " contain n = : " + cells.get(i).size());
            for (int j = 0; j < cells.get(i).size(); j++) { //adjust to isolate years
                cells.get(i).get(j).setCellType(CellType.STRING); //convert cell to numeric
                data.get(i).add(cells.get(i).get(j).getStringCellValue()); //convert cell to double and add to arraylist
            }
        }
        //-------------------input data end-------------------------------------
    }

    public static void printD(ArrayList<ArrayList<Double>> d) {

        for (int i = 0; i < d.size(); i++) {
            for (int j = 0; j < d.get(i).size(); j++) {
                System.out.print(d.get(i).get(j) + " ");
            }
            System.out.println();
        }
    }

}
