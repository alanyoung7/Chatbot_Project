package NN;

import edu.cmu.lti.lexical_db.ILexicalDatabase;
import edu.cmu.lti.lexical_db.NictWordNet;
import edu.cmu.lti.ws4j.RelatednessCalculator;
import edu.cmu.lti.ws4j.impl.HirstStOnge;
import edu.cmu.lti.ws4j.impl.JiangConrath;
import edu.cmu.lti.ws4j.impl.LeacockChodorow;
import edu.cmu.lti.ws4j.impl.Lesk;
import edu.cmu.lti.ws4j.impl.Lin;
import edu.cmu.lti.ws4j.impl.Path;
import edu.cmu.lti.ws4j.impl.Resnik;
import edu.cmu.lti.ws4j.impl.WuPalmer;
import edu.cmu.lti.ws4j.util.WS4JConfiguration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class Sim {

    private static ILexicalDatabase db = new NictWordNet();

    //available options of metrics
    private static RelatednessCalculator[] rcs = {
        new LeacockChodorow(db), new Lesk(db), new WuPalmer(db),
        new Resnik(db), new JiangConrath(db), new Lin(db), new Path(db)};

    ArrayList<ArrayList<String>> data = new ArrayList<>();
    ArrayList<String> BOW = new ArrayList<>();
    HashMap<Double, String> classes = new HashMap<>();

    Sim(ArrayList<ArrayList<String>> data) {

        this.data = data;
        BOW();
        System.out.println("Object created.....");
        System.out.println("BOW size: " + BOW.size() + " " + BOW.toString());
    }

    public double compute(String word1, String word2) {

        //WS4JConfiguration.getInstance().setMFS(true);
        //double s = new WuPalmer(db).calcRelatednessOfWords(word1, word2);
        double s = 0.0;
        for (int i = 0; i < rcs.length; i++) {
            Double temp = rcs[i].calcRelatednessOfWords(word1, word2);
            if (!Double.isInfinite(temp)) {

                s += temp;
            }
        }

        if (s < 1.0) {
            return s;
        } else {
            return 1.0;
        }
    }

    public ArrayList<ArrayList<Double>> getVecData(ArrayList<ArrayList<String>> data, Double scale) {

        ArrayList<ArrayList<Double>> d = new ArrayList<>();
        System.out.println("Vectorizing data....");

        for (int i = 0; i < BOW.size(); i++) {
            d.add(new ArrayList<>());
        }

        //vectorize the questions
        for (int i = 0; i < data.get(0).size(); i++) {
            ArrayList<String> t = new ArrayList<>();
            split(data.get(0).get(i), t);
            for (int j = 0; j < BOW.size(); j++) {
                String st = BOW.get(j);
                double sum = 0.0;
                for (int k = 0; k < t.size(); k++) {
                    sum += compute(st, t.get(k));
                }

                d.get(j).add(sum / scale);

            }
        }

        if (data.size() > 1) {
            d.add(new ArrayList<>());
            for (int i = 0; i < data.get(data.size() - 1).size(); i++) {
                d.get(d.size() - 1).add(Double.valueOf(data.get(data.size() - 1).get(i)));
            }
        }

        return d;
    }

    public void BOW() {

        ArrayList<String> s = new ArrayList<>(data.get(0));
        Set hs = new HashSet<>();
        for (int i = 0; i < s.size(); i++) {
            ArrayList<String> t = new ArrayList<>();
            split(s.get(i), t);
            for (int j = 0; j < t.size(); j++) {
                hs.add(t.get(j));
            }
        }

        BOW = new ArrayList<>(hs);

    }

    public static double norm(double x, double min, double max) {
        return (x - min) / (max - min);
    }

    static void split(String s, ArrayList<String> a) {

        String temp = "";
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) != ' ') {
                if (s.charAt(i) != ',' && s.charAt(i) != '.' && s.charAt(i) != '?') {
                    temp += s.charAt(i);
                }
            } else {
                a.add(temp.replaceAll("\\p{Punct}", ""));
                temp = "";
            }
        }
        //adds the last word in the statement
        a.add(temp.replaceAll("\\p{Punct}", ""));

    }

}
