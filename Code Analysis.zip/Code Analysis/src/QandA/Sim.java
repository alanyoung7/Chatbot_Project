package QandA;

import edu.cmu.lti.lexical_db.ILexicalDatabase;
import edu.cmu.lti.lexical_db.NictWordNet;
import edu.cmu.lti.ws4j.RelatednessCalculator;
import edu.cmu.lti.ws4j.impl.JiangConrath;
import edu.cmu.lti.ws4j.impl.LeacockChodorow;
import edu.cmu.lti.ws4j.impl.Lesk;
import edu.cmu.lti.ws4j.impl.Lin;
import edu.cmu.lti.ws4j.impl.Path;
import edu.cmu.lti.ws4j.impl.Resnik;
import edu.cmu.lti.ws4j.impl.WuPalmer;
import edu.cmu.lti.ws4j.util.WS4JConfiguration;
import java.util.ArrayList;

public class Sim {

    private static ILexicalDatabase db = new NictWordNet();

    //available options of metrics
    private static RelatednessCalculator[] rcs = {
        new LeacockChodorow(db), new Lesk(db), new WuPalmer(db),
        new Resnik(db), new JiangConrath(db), new Lin(db), new Path(db)};

    Sim() {

        System.out.println("Object created.....");
    }

    public double compute(String word1, String word2) {

        WS4JConfiguration.getInstance().setMFS(true);
        double s = new WuPalmer(db).calcRelatednessOfWords(word1, word2);

        if (s < 1.0) {
            return s;
        } else {
            return 1.0;
        }
    }

    public void split(String s, ArrayList<String> a, ArrayList<ArrayList<String>> sw) {

        String temp = "";
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) != ' ') {
                if (s.charAt(i) != ',' && s.charAt(i) != '.' && s.charAt(i) != '?') {
                    temp += s.charAt(i);
                }
            } else {
                a.add(temp.replaceAll("\\p{Punct}", ""));
                temp = "";
            }
        }
        //adds the last word in the statement
        a.add(temp.replaceAll("\\p{Punct}", ""));

        removeSW(a, sw);

    }

    public void removeSW(ArrayList<String> data, ArrayList<ArrayList<String>> sw) {

        for (int i = 0; i < sw.get(0).size(); i++) {
            for (int j = 0; j < data.size(); j++) {

                if (data.get(j).equals(sw.get(0).get(i))) {
                    data.remove(j);
                    j--;
                }
            }
        }
    }

}
