/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package QandA;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author jeffreyyoung
 */
public class QA {

    public static void main(String[] args) throws IOException, InterruptedException {

        disableWarning();
        ArrayList<ArrayList<String>> pre = new ArrayList<>();
        input(pre, "pre");
        makePre(pre);

        for (int i = 0; i < pre.get(1).size(); i++) {
            String t = pre.get(1).get(i), st = "";
            for (int j = 0; j < t.length(); j++) {

                if (t.charAt(j) != ' ') {
                    st += t.charAt(j);
                }
            }
            pre.get(1).remove(i);
            pre.get(1).add(i, st);
        }

        ArrayList<String> BOW = new ArrayList<>();
        ArrayList<ArrayList<String>> data = new ArrayList<>(); //stores inputs
        input(data, "qa");

        ArrayList<ArrayList<String>> sW = new ArrayList<>(); //stores inputs
        input(sW, "stopwords");

        //question
        ArrayList<String> Q = new ArrayList<>(data.get(0));
        //answer
        ArrayList<String> A = new ArrayList<>(data.get(1));

        Sim s = new Sim();

        while (true) {
            ArrayList<ArrayList<String>> out = readData();

            String bit = out.get(out.size() - 2).get(out.get(out.size() - 2).size() - 1);

            if (bit.equals("1")) {
                String q = findQ(pre, out.get(1).get(out.get(1).size() - 1));
                ArrayList<String> a = new ArrayList<>();
                s.split(q, a, sW);
                double sim = 0.0;
                int n = 0;
                for (int i = 0; i < Q.size(); i++) {
                    ArrayList<String> b = new ArrayList<>();
                    s.split(Q.get(i), b, sW);

                    //used to fill BOW
                    for (int j = 0; j < b.size(); j++) {
                        BOW.add(b.get(j));
                    }

                    double sum = 0.0;
                    for (int j = 0; j < a.size(); j++) {
                        for (int k = 0; k < b.size(); k++) {
                            sum += s.compute(a.get(j), b.get(k));
                        }
                    }
                    if ((sum / Q.get(i).length()) > sim) {
                        //System.out.println(Q.get(i));
                        sim = sum / Q.get(i).length();
                        n = i;
                    }
                }

                ArrayList<ArrayList<String>> output = new ArrayList<>();

                for (int j = 0; j < out.size(); j++) {
                    output.add(new ArrayList<>());
                    for (int k = 0; k < out.get(j).size(); k++) {
                        output.get(j).add(out.get(j).get(k));
                    }
                }

                output.get(output.size() - 4).remove(output.get(output.size() - 4).size() - 1);
                output.get(output.size() - 4).add(out.get(1).get(out.get(1).size() - 1));

                output.get(output.size() - 2).remove(output.get(output.size() - 2).size() - 1);
                output.get(output.size() - 2).add("0");

                output.get(output.size() - 1).remove(output.get(output.size() - 1).size() - 1);
                output.get(output.size() - 1).add(A.get(n));

                printS(output);

                writeData(flip(output));
            } else {
                System.out.println("Waiting on question...");
                System.out.println("bit: " + bit);
            }

            Thread.sleep(10000);

        }
    }

    public static String findQ(ArrayList<ArrayList<String>> pre, String s) {

        String s1 = s.toLowerCase().replaceAll("\\p{Punct}", "");
        //System.out.println(s1);

        ArrayList<String> q = new ArrayList<>();
        String t = "";
        for (int i = 0; i < s1.length(); i++) {
            if (s1.charAt(i) != ' ') {
                t += s1.charAt(i);
            } else {
                q.add(t);
                t = "";
            }
        }
        q.add(t);

        String question = "";
        outer:
        for (int i = 0; i < pre.get(0).size(); i++) {

            for (int j = 0; j < q.size() - 1; j++) {
                if (q.get(j).equals(pre.get(0).get(i)) && q.get(j + 1).equals(pre.get(1).get(i))) {

                    for (int k = j; k < q.size(); k++) {
                        question += (q.get(k) + " ");
                    }
                    break outer;
                }
            }
        }
        if (question.length() > 0) {
            System.out.println(question);
            return question;
        } else {
            return s;
        }

    }

    public static void makePre(ArrayList<ArrayList<String>> pre) {
        ArrayList<ArrayList<String>> temp = new ArrayList<>();

        for (int i = 0; i < pre.size(); i++) {
            temp.add(new ArrayList<>());
            for (int j = 0; j < pre.get(0).size(); j++) {
                temp.get(i).add(pre.get(i).get(j));
            }
        }

        pre.clear();
        pre.add(new ArrayList<>());
        pre.add(new ArrayList<>());
        for (int i = 0; i < temp.get(0).size(); i++) {
            String st = temp.get(0).get(i);
            for (int j = 0; j < temp.get(0).size(); j++) {
                pre.get(0).add(st);
                pre.get(1).add(temp.get(1).get(j));
            }
        }

    }

    public static ArrayList<ArrayList<String>> flip(ArrayList<ArrayList<String>> a) {

        ArrayList<ArrayList<String>> t = new ArrayList<>();
        for (int i = 0; i < a.get(0).size(); i++) {
            t.add(new ArrayList<>());
            for (int j = 0; j < a.size(); j++) {
                t.get(i).add(a.get(j).get(i));
            }
        }

        return t;
    }

    public static ArrayList<ArrayList<String>> readData() throws IOException {
        int count = 0;
        String file = "//Users/jeffreyyoung/Desktop/ChatBot/Bob/3.0/output.csv";
        List<String[]> content = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line = "";
            while ((line = br.readLine()) != null) {
                content.add(line.split(","));
            }
        } catch (FileNotFoundException e) {
            //Some error logging
        }
        ArrayList<ArrayList<String>> s = new ArrayList<>();
        for (int i = 0; i < content.get(0).length; i++) {
            s.add(new ArrayList<>());
            for (int j = 0; j < content.size(); j++) {
                s.get(i).add(content.get(j)[i]);
            }
        }
        return s;
    }

    public static void writeData(ArrayList<ArrayList<String>> rows) throws IOException {

        FileWriter csvWriter = null;

        csvWriter = new FileWriter("//Users/jeffreyyoung/Desktop/chatBot/Bob/3.0/output.csv");

        for (int i = 0; i < rows.size(); i++) {
            for (int j = 0; j < rows.get(i).size(); j++) {
                csvWriter.append(rows.get(i).get(j));
                if (j != rows.get(i).size() - 1) {
                    csvWriter.append(",");
                }
            }
            csvWriter.append("\n");
        }

        csvWriter.flush();
        csvWriter.close();
    }

    public static void disableWarning() {
        System.err.close();
        System.setErr(System.out);
    }

    public static void input(ArrayList<ArrayList<String>> data, String name) throws IOException {

        ArrayList<ArrayList<XSSFCell>> cells = new ArrayList<>();

        File myFile = new File("//Users/jeffreyyoung/Desktop/ChatBot/Data/" + name + ".xlsx");
        FileInputStream fis = new FileInputStream(myFile);

        XSSFWorkbook wb = new XSSFWorkbook(fis);

        XSSFSheet sheet = wb.getSheetAt(0);

        XSSFRow row;
        XSSFCell cell = null;

        int rows; // No of rows
        rows = sheet.getPhysicalNumberOfRows();

        System.out.println("rows = " + rows);
        int cols = 0; // No of columns
        int tmp = 0;

        // This trick ensures that we get the data properly even if it doesn't start from first few rows
        for (int i = 0; i < 10 || i < rows; i++) {
            row = sheet.getRow(i);
            if (row != null) {
                tmp = sheet.getRow(i).getPhysicalNumberOfCells();
                if (tmp > cols) {
                    cols = tmp;
                }
            }
        }
        for (int n = 0; n < cols; n++) {
            cells.add(new ArrayList<>()); //fills arraylists for number of columns
            data.add(new ArrayList<>());
        }

        System.out.println("rows 2: " + rows);
        System.out.println("cols: " + cols);
        for (int r = 0; r < rows * 2; r++) { //*2 to fix halfing problem
            row = sheet.getRow(r);
            if (row != null) {
                for (int c = 0; c < cols; c++) {
                    cell = row.getCell((short) c);
                    if (cell != null) {
                        cells.get(c % cols).add(cell);
                    }
                }
            }
        }

        for (int i = 0; i < cells.size(); i++) {
            System.out.println("Cell " + i + " contain n = : " + cells.get(i).size());
            for (int j = 0; j < cells.get(i).size(); j++) { //adjust to isolate years
                cells.get(i).get(j).setCellType(CellType.STRING); //convert cell to numeric
                data.get(i).add(cells.get(i).get(j).getStringCellValue()); //convert cell to double and add to arraylist
            }
        }
        //-------------------input data end-------------------------------------
    }

    public static void printS(ArrayList<ArrayList<String>> d) {

        for (int i = 0; i < d.get(0).size(); i++) {
            for (int j = 0; j < d.size(); j++) {
                System.out.print(d.get(j).get(i) + " ");
            }
            System.out.println();
        }
    }

}
